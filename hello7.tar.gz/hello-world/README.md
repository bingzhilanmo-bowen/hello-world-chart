# HelloWorld Helm chart
## Desc
* java 8 + Springboot 2.x 
To install the chart with the release name `my-release`:

```bash
$ helm install --name my-release hello-world